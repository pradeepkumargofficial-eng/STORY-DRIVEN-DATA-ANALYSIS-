"""
dashboard/app.py
-----------------
Interactive Streamlit dashboard for the Story-Driven Data Analysis project.

Run with:
    streamlit run dashboard/app.py

The dashboard reuses the exact same aggregation and charting logic as the
notebooks (src/eda.py, src/visualization.py) so numbers are always
consistent across the notebooks, static images, and this app.
"""

import os
import sys

import pandas as pd
import streamlit as st

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.utils import PROCESSED_DATA_PATH, RAW_DATA_PATH, kpi_summary, currency, pct
from src.data_cleaning import run_pipeline
from src import eda, visualization as viz, forecasting as fc

st.set_page_config(
    page_title="Story-Driven Sales Dashboard",
    page_icon="📊",
    layout="wide",
)


@st.cache_data(show_spinner="Loading and preparing data...")
def get_data() -> pd.DataFrame:
    """Load the cleaned dataset, generating it on first run if needed."""
    if not os.path.exists(PROCESSED_DATA_PATH):
        run_pipeline(RAW_DATA_PATH, PROCESSED_DATA_PATH)
    df = pd.read_csv(PROCESSED_DATA_PATH, parse_dates=["Order Date", "Ship Date"])
    return df


def sidebar_filters(df: pd.DataFrame) -> pd.DataFrame:
    st.sidebar.header("🔎 Filters")

    min_date, max_date = df["Order Date"].min(), df["Order Date"].max()
    date_range = st.sidebar.date_input(
        "Order Date Range", value=(min_date, max_date), min_value=min_date, max_value=max_date
    )

    regions = sorted(df["Region"].unique())
    selected_regions = st.sidebar.multiselect("Region", regions, default=regions)

    categories = sorted(df["Category"].unique())
    selected_categories = st.sidebar.multiselect("Category", categories, default=categories)

    segments = sorted(df["Segment"].unique())
    selected_segments = st.sidebar.multiselect("Segment", segments, default=segments)

    if len(date_range) == 2:
        start, end = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
    else:
        start, end = min_date, max_date

    filtered = df[
        (df["Order Date"] >= start)
        & (df["Order Date"] <= end)
        & (df["Region"].isin(selected_regions))
        & (df["Category"].isin(selected_categories))
        & (df["Segment"].isin(selected_segments))
    ]
    return filtered


def kpi_row(df: pd.DataFrame) -> None:
    kpis = kpi_summary(df)
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total Sales", currency(kpis["total_sales"]))
    c2.metric("Total Profit", currency(kpis["total_profit"]))
    c3.metric("Profit Margin", pct(kpis["profit_margin"]))
    c4.metric("Orders", f"{kpis['total_orders']:,}")
    c5.metric("Avg. Order Value", currency(kpis["avg_order_value"]))


def main():
    st.title("📊 Story-Driven Sales & Business Insights Dashboard")
    st.caption(
        "Interactive companion to the Story-Driven Data Analysis project — "
        "filter the data on the left and explore sales, profit, customers, "
        "regions, and a short-term sales forecast."
    )

    df = get_data()
    filtered = sidebar_filters(df)

    if filtered.empty:
        st.warning("No data matches the selected filters. Please broaden your selection.")
        return

    kpi_row(filtered)
    st.divider()

    tab_trend, tab_profit, tab_customers, tab_region, tab_forecast = st.tabs(
        ["📈 Sales Trend", "💰 Profit Analysis", "🧑‍🤝‍🧑 Customers", "🗺️ Regional", "🔮 Forecast"]
    )

    with tab_trend:
        monthly = eda.monthly_sales_trend(filtered)
        st.plotly_chart(viz.plotly_sales_trend(monthly), use_container_width=True)
        yoy = eda.yearly_growth(filtered)
        st.subheader("Year-over-Year Growth")
        st.dataframe(yoy, use_container_width=True)

    with tab_profit:
        cat_perf = eda.profit_by_category(filtered)
        st.plotly_chart(viz.plotly_category_treemap(cat_perf), use_container_width=True)
        col1, col2 = st.columns(2)
        with col1:
            st.subheader("Profit by Sub-Category")
            st.dataframe(cat_perf, use_container_width=True)
        with col2:
            st.subheader("Discount vs Profit")
            st.plotly_chart(viz.plotly_scatter_discount_profit(filtered), use_container_width=True)
            discount_effect = eda.discount_vs_profit(filtered)
            st.dataframe(discount_effect, use_container_width=True)

    with tab_customers:
        customers = eda.customer_segmentation(filtered)
        st.plotly_chart(viz.plotly_customer_scatter(customers), use_container_width=True)
        st.subheader("Segment Performance")
        st.dataframe(eda.segment_performance(filtered), use_container_width=True)
        st.subheader("Top 10 Customers by Sales")
        st.dataframe(customers.head(10), use_container_width=True)

    with tab_region:
        region_perf = eda.regional_performance(filtered)
        st.plotly_chart(viz.plotly_region_bar(region_perf), use_container_width=True)
        st.subheader("State-Level Performance")
        st.dataframe(eda.state_performance(filtered), use_container_width=True)

    with tab_forecast:
        st.subheader("6-Month Sales Forecast")
        horizon = st.slider("Forecast horizon (months)", 3, 12, 6)
        result = fc.forecast_sales(filtered, periods=horizon)
        accuracy = fc.forecast_accuracy(result)

        import plotly.graph_objects as go
        fig = go.Figure()
        hist = result[~result["is_forecast"]]
        fig.add_trace(go.Scatter(x=hist["ds"], y=hist["sales"], name="Actual Sales", mode="lines"))
        fig.add_trace(go.Scatter(x=result["ds"], y=result["forecast"], name="Forecast", mode="lines",
                                  line=dict(dash="dash")))
        fig.update_layout(title="Sales Forecast", xaxis_title="Month", yaxis_title="Sales ($)")
        st.plotly_chart(fig, use_container_width=True)
        st.caption(f"In-sample accuracy — MAE: {currency(accuracy['MAE'])}, MAPE: {accuracy['MAPE_%']}%")

    st.divider()
    st.caption(
        "Built with Python, Pandas, Plotly, and Streamlit as part of the "
        "Story-Driven Data Analysis project. See notebooks/03_business_insights.ipynb "
        "for the full narrative and recommendations."
    )


if __name__ == "__main__":
    main()
