# Dashboard Screenshots

Add PNG/JPG screenshots of the running Streamlit dashboard (or the Power BI
`.pbix` report) here for documentation purposes, e.g.:

```
dashboard_screenshots/
├── 01_overview_tab.png
├── 02_profit_analysis_tab.png
├── 03_customer_segmentation_tab.png
├── 04_regional_performance_tab.png
└── 05_forecast_tab.png
```

To capture one:
1. Run `streamlit run dashboard/app.py`
2. Open the app in your browser
3. Take a screenshot of each tab and save it here
4. Reference the images in the main `README.md` under the **Dashboard** section
